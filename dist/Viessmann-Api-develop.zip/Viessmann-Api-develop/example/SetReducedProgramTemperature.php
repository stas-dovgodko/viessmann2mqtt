<?php
include __DIR__.'/bootstrap.php';
$viessmannApi->setReducedProgramTemperature("20");