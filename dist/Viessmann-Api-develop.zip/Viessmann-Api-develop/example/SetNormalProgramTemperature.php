<?php
include __DIR__.'/bootstrap.php';
$viessmannApi->setNormalProgramTemperature("20");