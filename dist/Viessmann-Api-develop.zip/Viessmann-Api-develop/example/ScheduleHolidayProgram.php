<?php
include __DIR__.'/bootstrap.php';
$viessmannApi->scheduleHolidayProgram("2019-08-02","2019-08-08");//not sure of the format.
