<?php
include __DIR__.'/bootstrap.php';
echo "InstallationId: ".$viessmannApi->getInstallationId()."\n";
echo "GatewayId: ".$viessmannApi->getGatewayId();
