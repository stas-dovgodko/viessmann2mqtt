<?php
include __DIR__.'/bootstrap.php';
echo $viessmannApi->setCurve("-2", "0.7");