<?php
include __DIR__ . '/bootstrap.php';
echo $viessmannApi->getBoilerTemperature();