<?php
include __DIR__.'/bootstrap.php';
echo (int)$viessmannApi->isHeatingBurnerActive();